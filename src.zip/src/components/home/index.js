
import Layout from "../layout";
const onSubmit = (e) =>{
  e.preventDefault();
}
const clickBtn = () => {
  const getValue = document.getElementById('myInput').value;
  if(getValue !== ''){
    const shhows = document.getElementById('result');
    const item = document.createElement('div');
    item.innerHTML = "<input type='checkbox' id='vehicle2'><span>"+getValue+"</span><button class='btnDelete'>Xoá</button>" ;
    shhows.appendChild(item);
    document.getElementById('myInput').value = '';
  }
  
}
const Homepage = () => {
  return <Layout id="home-page-layout">
    <form action="" method="post" onSubmit = {onSubmit}>
      <div id="enter">
        <input id="myInput" placeholder = "Add task..." type="text" />
        <button onClick={clickBtn} type="submit">Clickk</button>
      </div>
      <div id="result"></div>
      <div id ="calular">
        <span id = "task">1 Task</span>
        <span id = "complete">0 Complete</span>
        <span id = "open">0 Open</span>
      </div>
    </form>
    
  </Layout>;
};

export default Homepage;
