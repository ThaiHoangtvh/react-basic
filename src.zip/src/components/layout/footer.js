const Footer = () => {
    return (
      <div id="footer">
        <a href="google.com">About</a>
      </div>
    );
  };
  
  export default Footer;
  