// import logo from './logo.svg';
import './App.css';
import Homepage from "./components/home";

const App = () => {
  return <Homepage> Content APP</Homepage>;
};

export default App;
